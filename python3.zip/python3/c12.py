import sys
import datetime
import io

print(sys.path)
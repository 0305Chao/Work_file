
yello = 1
green = 2
{'yellow':1,'green':2}



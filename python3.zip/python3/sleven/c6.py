from enum import Enum
from enum import IntEnum
from enum import Enum


@unique
class VIP(IntEnum):
    YELLOW = 1
    GREEN = 1
    RED = 2
    BREAK = 3




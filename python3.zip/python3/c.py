from t import *
print(c8.a)
print(c7.a)
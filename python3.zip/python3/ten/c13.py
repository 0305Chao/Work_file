# sub 替换
import re
lanuage = 'PythonC#javaPhpphpC#pytC#hon'
#4~8
r = re.sub('C#', 'lian' ,lanuage,1)

a = lanuage.replace('Python','Chao')
print(r)
print(a)
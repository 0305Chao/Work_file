#from p3 import p3
p2 = 2
print (p2)
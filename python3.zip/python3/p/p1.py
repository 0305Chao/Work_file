# from p2 import p2
# p1 = 2
# print (p2)
import p2

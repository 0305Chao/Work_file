'''
account = 'wuchao'
password = '123456'

print('please input account')
user_account = input()
print('please input passworld')
user_password = input()

if account == user_account and password == user_password :
    print('success')
else :
    print('fail')
'''
AfdaCCOUNT = 'wuchao'
PASSWORLD = '123456'

print('please input account')
USER_ACCOUNT = input()
print('please input passworld')
USER_PASSWORLD = input()

if ACCOUNT == USER_ACCOUNT and PASSWORLD == USER_PASSWORLD :
    print('success')
else 
    print('fail')
# snippet1

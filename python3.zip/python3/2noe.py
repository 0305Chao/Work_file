
from noe import *

print (a)
print (b)
print (c)
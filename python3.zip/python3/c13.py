import t 
print(t.sys.path)
#函数

a = 1.23456

result = round(a, 2)
print (result)

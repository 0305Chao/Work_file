def add(x ,y):
    #形式参数 形参
    result = x + y 
    return result

c = add(y=3, x=2)
d = add(4,5)
print (c)
print(d)
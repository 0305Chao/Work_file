
from python3.note import *

a = 'a'
b = 'b'
c = 'c'
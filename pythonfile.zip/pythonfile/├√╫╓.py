name = input("Please enter your name: ")
print("Hello ," + name.title() + " !")

prompt = ("If you name is yousee")

prompt += ("\nWhat is your first name")

names = input(prompt)

print("\nHello , " + name.title() + " !")

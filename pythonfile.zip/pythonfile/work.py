chao=["a","b","c","d"]

'''
print(chao)
'''

print("my whant a go to work.")
for lian in chao:
    if lian == "a":
        print("sorry a, a working.")
    else:
        aa=(chao[1:])
        print("yourd go to " + lian.title()  + "  working")

print("\nThink you.")

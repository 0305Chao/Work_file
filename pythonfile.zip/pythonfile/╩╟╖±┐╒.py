likes = ["a","b"]
if likes:
    for like in likes:
        print("\nthis is  " + like + "  not")
    print("\n这是没有的")
else:
    print("\nthis is your")

likes = [""]
if likes:
    for like in likes:
        print("\nthis is  " + like + "  not")
    print("\n这是没有的")
else:
    print("\n\nthis is your")


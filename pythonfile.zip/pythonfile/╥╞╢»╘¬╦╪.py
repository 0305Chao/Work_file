
a = ['莲莲','超超','汐汐']

b = []

while a:
    c = a.pop()
    print("Verifying user: " + c.title())
    b.append(c)
print("\nThe following user have been confirmed: ")
for d in b:
    print(c.title())

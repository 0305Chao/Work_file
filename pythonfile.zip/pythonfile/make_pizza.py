import pizza


pizza.make_pizza(18, 'test1')
pizza.make_pizza(19, 'test2','test3', 'test4')


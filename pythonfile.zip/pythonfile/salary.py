Name = input("your name is: ")

Age = input("my age is: ")

Job = input("my Job is: ")

Salary = input("my salary is : ")

print ('''

Personal ifornamtion of %s:
            Name: %s
            Age : %s
            Job : %s
            Salary: %s

______________________________________________


''' % (Name,Name, Age, Job, Salary))




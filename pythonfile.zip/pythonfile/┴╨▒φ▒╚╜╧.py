lians=["最美","漂亮","小公主","小仙女"]
xixis=["最美","乖","小仙女","听话"]

for xixi in lians:
    if xixi in xixis:
        print("xixi" + xixi)
    else:
        print("lianlian" + xixi )
print("\nwuchao 也挺帅的")
